module SeveritiesHelper
end
