require 'snorby/model/types/numeric_ip_addr'
