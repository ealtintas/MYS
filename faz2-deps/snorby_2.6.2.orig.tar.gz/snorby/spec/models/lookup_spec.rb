require 'spec_helper'

describe Lookup do
  pending "add some examples to (or delete) #{__FILE__}"
end
