require 'test_helper'

class SensorsHelperTest < ActionView::TestCase
end
