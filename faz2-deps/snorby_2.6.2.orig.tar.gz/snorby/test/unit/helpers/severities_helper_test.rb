require 'test_helper'

class SeveritiesHelperTest < ActionView::TestCase
end
